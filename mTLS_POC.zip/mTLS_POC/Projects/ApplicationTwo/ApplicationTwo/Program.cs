﻿
using Microsoft.AspNetCore.Server.Kestrel.Https;
using System.Net.Security;

namespace ApplicationTwo
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.WebHost.ConfigureKestrel(options =>
            {
                options.ConfigureHttpsDefaults(httpsOptions =>
                {
                    httpsOptions.ClientCertificateMode = ClientCertificateMode.RequireCertificate;

                    httpsOptions.ClientCertificateValidation = (cert, chain, errors) =>
                    {
                        // Basic validation → done automatically (expiry, trusted root etc.)
                        if (errors != SslPolicyErrors.None)
                            return false;

                        // Simple example → only allow specific clients
                        var allowedClients = new[] { "application_three" };

                        return cert.Subject
                            .Split(',')
                            .Select(part => part.Trim())
                            .Where(part => part.StartsWith("CN="))
                            .Select(part => part.Substring(3)) // Extract the value after "CN="
                            .Any(cn => allowedClients.Contains(cn));

                    };
                });
            });

            // Add services to the container.

            builder.Services.AddControllers();
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            builder.Services.AddEndpointsApiExplorer();
            builder.Services.AddSwaggerGen();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseSwagger();
                app.UseSwaggerUI();
            }

            app.UseHttpsRedirection();

            app.UseAuthorization();


            app.MapControllers();

            app.Run();
        }
    }
}
